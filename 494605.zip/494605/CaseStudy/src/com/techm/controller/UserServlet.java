package com.techm.controller;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techm.dao.UserDao;
import com.techm.dao.UserDaoImpl;
import com.techm.dto.User1;
import com.techm.util.JdbcConnection;


public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		 response.setContentType("text/html"); 
		  PrintWriter out=response.getWriter();
		  Connection con=JdbcConnection.getConnection();
		  
		  String m_username=request.getParameter("UserName");
		  String m_gender=request.getParameter("Gender");
		  String m_city=request.getParameter("City");
		  String m_state=request.getParameter("State");
		 String m_pincode=request.getParameter("PinCode");
		  String m_emailid=request.getParameter("EmailId");
		  String m_mobileno=request.getParameter("MobileNo");
		  String m_password=request.getParameter("Password");
		   
		 
		 User1 u=new User1(m_username, m_gender, m_city, m_state, m_pincode, m_emailid, Long.parseLong(m_mobileno), m_password);
		 UserDao ud=new UserDaoImpl();
		 
		 boolean rec=ud.insert(u);
		 if(rec==true)
		 {
			 RequestDispatcher rd=request.getRequestDispatcher("Reg_Successful.jsp");
			 rd.forward(request, response);
		 }
	}
	}


