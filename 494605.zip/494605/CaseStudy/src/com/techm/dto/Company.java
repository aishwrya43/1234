package com.techm.dto;

public class Company {

	int Company_id;
	String Company_name;
	int NoOfShares;
	public Company(int company_id, String company_name, int noOfShares) {
		super();
		Company_id = company_id;
		Company_name = company_name;
		NoOfShares = noOfShares;
	}
	public int getCompany_id() {
		return Company_id;
	}
	public void setCompany_id(int company_id) {
		Company_id = company_id;
	}
	public String getCompany_name() {
		return Company_name;
	}
	public void setCompany_name(String company_name) {
		Company_name = company_name;
	}
	public int getNoOfShares() {
		return NoOfShares;
	}
	public void setNoOfShares(int noOfShares) {
		NoOfShares = noOfShares;
	}
	
	
}
