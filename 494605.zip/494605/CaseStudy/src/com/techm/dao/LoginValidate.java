package com.techm.dao;

import com.techm.dto.Login;

public interface LoginValidate {

	public String userValidate(String username,String password);
	public String adminValidate(Login al);
}
