package com.techm.dao;

import com.techm.dto.Company;

public interface CompanyDao {

	boolean insertcompany (Company p);
}
