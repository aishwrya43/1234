package com.techm.dao;

import com.techm.dto.Login;

public class LoginDaoImpl implements LoginDao {

	public String validateUser(Login login) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
