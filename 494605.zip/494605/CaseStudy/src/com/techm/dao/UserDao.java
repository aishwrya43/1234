package com.techm.dao;

import com.techm.dto.User1;

public interface UserDao {

	boolean insert(User1 p);
	//List<User1> display();

}
