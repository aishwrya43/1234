package com.techm.dao;

import java.util.ArrayList;

import com.techm.dto.User1;

public interface UserDispalyDao {

	public ArrayList<User1> display (User1 u);
	
}
