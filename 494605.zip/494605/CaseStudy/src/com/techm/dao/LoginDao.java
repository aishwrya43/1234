package com.techm.dao;

import com.techm.dto.Login;

public interface LoginDao {

	public abstract String validateUser(Login login);
}
