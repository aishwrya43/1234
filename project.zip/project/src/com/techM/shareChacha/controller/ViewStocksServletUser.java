package com.techM.shareChacha.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaDB.UserDB;

/**
 * Servlet implementation class ViewStocksServletUser
 */
public class ViewStocksServletUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewStocksServletUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
			
		HttpSession session = request.getSession(false);
		try {
		UserDB uDB = new UserDB();
		
		ArrayList<Company> alist3= new ArrayList<Company>();
		alist3 = uDB.getStocks();
		
		/*for( Company cc : alist3 )
		System.out.print(cc.getCompanyID());*/
				
		if( alist3 != null ) {
			session.setAttribute("stockList3", alist3);
			
			RequestDispatcher rd = request.getRequestDispatcher("/viewSharesUser.jsp");
			rd.forward(request, response);
		}
		else if( alist3 == null ) {
			throw new Exception();
		}
		} catch (Exception e) {	
			session.setAttribute("status2", "Error while fetching the data. Please try again..");
			
			RequestDispatcher rd = request.getRequestDispatcher("/user.jsp");
			rd.forward(request, response);
		}
	}
	}


